<?php

class Dozent extends Person {

    // 1a) Die Klasse Dozent bekommt als eigene Attribute $fachbereich und $titel.

    // 1b) Schützen Sie diese Attribute durch Zugriff ausschließlich über Getter
    // bzw. Setter-Methoden.

    // 1c) Überschreiben Sie den Konstruktor der Oberklasse für die beiden neuen
	// Attribute und wieder verwenden Sie die Logik des Konstruktors der Oberklasse.

    // 1d) Überschreiben Sie die toString-Methode, wobei die Logik des Oberklasse
	// wieder verwendet werden soll und um die Ausgabe der neuen Attribute erweitert wird.

}

?>